const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// داتابەیزی کاتی لە میمۆری
let promoteVideos = [
    {
        id: "7212345678901234567",
        originalUrl: "https://www.tiktok.com/@tiktok/video/7212345678901234567",
        createdAt: new Date()
    }
];

// جیاکردنەوەی Video ID لە لینکی تیکتۆک
function extractTikTokId(url) {
    const regex = /(?:video\/|v\/|embed\/|v=|\/)([0-9]{18,20})/;
    const match = url.match(regex);
    return match ? match[1] : null;
}

// API: وەرگرتنی هەموو ڤیدیۆیە چالاکەکان
app.get('/api/videos', (req, res) => {
    res.json({ success: true, videos: promoteVideos });
});

// API: زادکردنی لینکی نوێ
app.post('/api/add-video', (req, res) => {
    const { tiktokUrl } = req.body;

    if (!tiktokUrl) {
        return res.status(400).json({ success: false, message: 'تکایە لینکێک بنووسە.' });
    }

    const videoId = extractTikTokId(tiktokUrl);

    if (!videoId) {
        return res.status(400).json({ success: false, message: 'لینکی تیکتۆکەکە هەڵەیە یان نادروستە.' });
    }

    const newVideo = {
        id: videoId,
        originalUrl: tiktokUrl,
        createdAt: new Date()
    };

    promoteVideos.unshift(newVideo);
    res.json({ success: true, message: 'ڤیدیۆکەت بە سەرکەوتوویی زیادرکرا!', video: newVideo });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
