document.addEventListener('DOMContentLoaded', () => {
    loadVideos();
});

async function loadVideos() {
    try {
        const response = await fetch('/api/videos');
        const data = await response.json();

        if (data.success) {
            renderFeed(data.videos);
        }
    } catch (err) {
        console.error('Error loading videos:', err);
    }
}

function renderFeed(videos) {
    const feed = document.getElementById('videoFeed');
    feed.innerHTML = '';

    if (videos.length === 0) {
        feed.innerHTML = '<div class="video-card"><p>هیچ ڕیکلامێک بەردەست نییە.</p></div>';
        return;
    }

    videos.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';

        const embedUrl = `https://www.tiktok.com/player/v1/${video.id}?autoplay=1`;
        const deepLink = `snssdk1128://aweme/detail/${video.id}`;

        videoCard.innerHTML = `
            <iframe class="tiktok-player" src="${embedUrl}" allow="autoplay; encrypted-media"></iframe>
            
            <div class="side-bar">
                <a href="${deepLink}" class="action-btn like-btn" title="لایک لە ئەپی تیکتۆک">
                    ❤️
                </a>
                <a href="${video.originalUrl}" target="_blank" class="action-btn" title="کردنەوە لە تیکتۆک">
                    🔗
                </a>
            </div>
        `;

        feed.appendChild(videoCard);
    });
}

function toggleModal(show) {
    const modal = document.getElementById('modalOverlay');
    modal.style.display = show ? 'flex' : 'none';
}

async function submitVideo() {
    const urlInput = document.getElementById('tiktokUrlInput');
    const tiktokUrl = urlInput.value.trim();

    if (!tiktokUrl) {
        alert('تکایە لینک بئاخنە!');
        return;
    }

    try {
        const response = await fetch('/api/add-video', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tiktokUrl })
        });

        const data = await response.json();

        if (data.success) {
            alert(data.message);
            urlInput.value = '';
            toggleModal(false);
            loadVideos();
        } else {
            alert(data.message);
        }
    } catch (err) {
        alert('کێشەیەک لە پەیوەندی دروست بوو.');
    }
}
